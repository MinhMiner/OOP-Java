public class Numeral extends Expression {
    private double value;

    /** Default constructor. */
    public Numeral() {

    }

    /** Constructor with initial value. */
    public Numeral(double value) {
        this.value = value;
    }

    /** toString() method. */
    public String toString() {
        return String.format("%.0f", value);
    }

    /** evaluate() method. */
    public double evaluate() {
        return value;
    }
}
