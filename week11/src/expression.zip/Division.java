public class Division extends BinaryExpression {
    /** Constructor. */
    public Division(Expression left, Expression right) {
        super(left, right);
    }

    /** toString() method. */
    public String toString() {
        return String.format("(%s / %s)", left.toString(), right.toString());
    }

    /** evaluate() method. */
    public double evaluate() throws java.lang.ArithmeticException {
        if (right.evaluate() == 0) {
            throw new java.lang.ArithmeticException("Lỗi chia cho 0");
        }
        return left.evaluate() / right.evaluate();
    }
}
