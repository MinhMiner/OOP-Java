public class Subtraction extends BinaryExpression {
    /** Constructor. */
    public Subtraction(Expression left, Expression right) {
        super(left, right);
    }

    /** toString() method. */
    public String toString() {
        return String.format("(%s - %s)", left.toString(), right.toString());
    }

    /** evaluate() method. */
    public double evaluate() {
        return left.evaluate() - right.evaluate();
    }
}
