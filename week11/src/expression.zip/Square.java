public class Square extends Expression {
    private Expression expression;

    /** Constructor. */
    public Square(Expression expression) {
        this.expression = expression;
    }

    /** toString() method. */
    public String toString() {
        return String.format("(%s) ^ 2", expression.toString());
    }

    /** evaluate() method. */
    public double evaluate() {
        return expression.evaluate() * expression.evaluate();
    }
}
